/**
 * Одностраничный демо-сайт + POST /api/from-1c для приёма JSON из 1С.
 * Запуск: npm install && npm start
 * Открыть: http://localhost:3000
 */
const path = require("path");
const express = require("express");

const app = express();
const PORT = process.env.PORT || 3000;

// Токен из переменной окружения или простой ключ для учебного стенда
const API_SECRET = process.env.API_SECRET || "demo-secret-1c";

app.use(express.json({ limit: "512kb" }));
app.use(express.urlencoded({ extended: true }));

/** Последние сообщения (в памяти), новые сверху */
const messages = [];
const MAX = 100;

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/api/messages", (req, res) => {
  res.json({
    ok: true,
    count: messages.length,
    items: messages,
  });
});

/** Очистить журнал (данные в памяти) — для демо/записи видео */
app.delete("/api/messages", (req, res) => {
  messages.length = 0;
  console.log("[clear] журнал очищен");
  res.json({ ok: true, count: 0 });
});

/**
 * Сюда 1С отправляет JSON (POST).
 * Заголовок: Authorization: Bearer <API_SECRET>  (или x-api-key)
 */
app.post("/api/from-1c", (req, res) => {
  const auth =
    req.headers.authorization ||
    req.headers["x-api-key"] ||
    "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : auth;

  if (token !== API_SECRET) {
    return res.status(401).json({ ok: false, error: "unauthorized" });
  }

  const payload = {
    receivedAt: new Date().toISOString(),
    body: req.body,
    ip: req.ip || req.connection?.remoteAddress,
  };

  messages.unshift(payload);
  if (messages.length > MAX) messages.length = MAX;

  console.log("[from-1c]", JSON.stringify(payload, null, 2));

  res.json({ ok: true, id: messages.length });
});

// 0.0.0.0 — один процесс и для 1С (127.0.0.1), и для браузера (localhost).
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Открой в браузере: http://127.0.0.1:${PORT}`);
  console.log(`POST JSON сюда: http://127.0.0.1:${PORT}/api/from-1c`);
  console.log(`API_SECRET (Bearer): ${API_SECRET}`);
});
